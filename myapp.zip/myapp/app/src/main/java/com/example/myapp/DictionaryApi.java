package com.example.myapp;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

import java.util.List;

public interface DictionaryApi {
    @GET("api/v2/entries/en/{word}") // Use a public dictionary API
    Call<List<WordDefinition>> getWordDefinition(@Path("word") String word);
}
