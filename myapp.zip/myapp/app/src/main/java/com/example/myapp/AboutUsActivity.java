package com.example.myapp;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Html;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class AboutUsActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us); // Ensure you have a corresponding layout XML

        TextView aboutUsTextView = findViewById(R.id.aboutUsTextView);
        aboutUsTextView.setText(
                "<h2>App Overview</h2>" +
                        "<strong>Name:</strong> Spetex<br>" +
                        "<strong>Developers:</strong> Vishal Kumar and Harsha Chakoley<br>" +
                        "<strong>Mission:</strong> To enhance communication through innovative technology.<br><br>" +

                        "<h2>About the App</h2>" +
                        "Spetex is designed to be a user-friendly application aimed at making language and information more accessible to everyone. " +
                        "The application provides various features that empower users in their daily interactions and learning experiences.<br><br>" +

                        "<h2>Vision</h2>" +
                        "We aim to create solutions that foster communication and learning, bridging gaps in language and information accessibility for all individuals."
        );
        aboutUsTextView.setText(Html.fromHtml(aboutUsTextView.getText().toString(), Html.FROM_HTML_MODE_LEGACY));
    }
}
