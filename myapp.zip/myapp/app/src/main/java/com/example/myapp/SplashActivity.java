package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;

public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_DISPLAY_LENGTH = 2000; // Duration for splash screen

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(() -> {
            SharedPreferences prefs = getSharedPreferences("MyAppPreferences", MODE_PRIVATE);
            boolean hasSeenOnboarding = prefs.getBoolean("hasSeenOnboarding", false);

            if (hasSeenOnboarding) {
                // User has seen onboarding, proceed to MainActivity
                startActivity(new Intent(SplashActivity.this, MainActivity.class));
            } else {
                // User has not seen onboarding, go to OnboardingActivity
                startActivity(new Intent(SplashActivity.this, OnboardingActivity.class));
            }
            finish();
        }, SPLASH_DISPLAY_LENGTH);
    }
}
