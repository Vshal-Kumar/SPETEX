package com.example.myapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;
import java.util.ArrayList;
import java.util.List;

public class OnboardingActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private List<Integer> onboardingScreens;
    private View[] dotIndicators;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Check if onboarding has been completed
        SharedPreferences prefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
        boolean onboardingComplete = prefs.getBoolean("onboardingComplete", false);
        if (onboardingComplete) {
            // If onboarding is complete, navigate to MainActivity
            startActivity(new Intent(OnboardingActivity.this, MainActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_onboarding);

        viewPager = findViewById(R.id.viewPager);
        onboardingScreens = new ArrayList<>();
        onboardingScreens.add(R.layout.onboarding_screen_1);
        onboardingScreens.add(R.layout.onboarding_screen_2);
        onboardingScreens.add(R.layout.onboarding_screen_4);
        // Ensure you have exactly as many dot indicators as there are screens
        dotIndicators = new View[]{
                findViewById(R.id.dot1),
                findViewById(R.id.dot2),
                findViewById(R.id.dot3)
        };

        OnboardingAdapter adapter = new OnboardingAdapter(onboardingScreens, this);
        viewPager.setAdapter(adapter);

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                updateDotIndicators(position);
            }
        });

        findViewById(R.id.btnNext).setOnClickListener(view -> {
            if (viewPager.getCurrentItem() < onboardingScreens.size() - 1) {
                viewPager.setCurrentItem(viewPager.getCurrentItem() + 1);
            } else {
                completeOnboarding();
            }
        });

        findViewById(R.id.btnSkip).setOnClickListener(view -> completeOnboarding());
    }

    private void updateDotIndicators(int position) {
        for (int i = 0; i < dotIndicators.length; i++) {
            if (i == position) {
                dotIndicators[i].setBackgroundResource(R.drawable.active_circle);
            } else {
                dotIndicators[i].setBackgroundResource(R.drawable.circle);
            }
        }
    }

    private void completeOnboarding() {
        // Save onboarding completion status
        SharedPreferences prefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
        prefs.edit().putBoolean("onboardingComplete", true).apply();

        // Start MainActivity and finish OnboardingActivity
        startActivity(new Intent(OnboardingActivity.this, MainActivity.class));
        finish();
    }
}
