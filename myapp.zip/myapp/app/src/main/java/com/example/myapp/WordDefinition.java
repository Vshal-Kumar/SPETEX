package com.example.myapp;

import java.util.List;

public class WordDefinition {
    private String word;
    private List<Meaning> meanings;

    public String getWord() {
        return word;
    }

    public List<Meaning> getMeanings() {
        return meanings;
    }

    public static class Meaning {
        private String partOfSpeech;
        private List<Definition> definitions;

        public String getPartOfSpeech() {
            return partOfSpeech;
        }

        public List<Definition> getDefinitions() {
            return definitions;
        }

        public static class Definition {
            private String definition;

            public String getDefinition() {
                return definition;
            }
        }
    }
}
