package com.example.myapp;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class FeaturesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_features); // Create a corresponding layout XML
        TextView featuresTextView = findViewById(R.id.featuresTextView);
        String features = "✨ Here are the features of the application:\n\n" +
                "• User-friendly interface\n" +
                "• Real-time speech recognition\n" +
                "• Text-to-speech functionality\n" +
                "• speech-to-text functionality\n"+
                "• Ditionary functionality\n"+
                "• Offline capabilities\n" +
                "• Personalized settings\n" +
                "• Regular updates and support";

        featuresTextView.setText(features);
    }
}
