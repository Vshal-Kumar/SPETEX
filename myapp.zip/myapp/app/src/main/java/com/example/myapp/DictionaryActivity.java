package com.example.myapp;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.util.List;

public class DictionaryActivity extends AppCompatActivity {

    private EditText wordInput;
    private TextView definitionOutput;
    private Button searchButton;

    private static final String BASE_URL = "https://api.dictionaryapi.dev/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dictionary);

        wordInput = findViewById(R.id.word_input);
        definitionOutput = findViewById(R.id.definition_output);
        searchButton = findViewById(R.id.search_button);

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String word = wordInput.getText().toString();
                if (!word.isEmpty()) {
                    fetchDefinition(word);
                } else {
                    Toast.makeText(DictionaryActivity.this, "Please enter a word", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void fetchDefinition(String word) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        DictionaryApi dictionaryApi = retrofit.create(DictionaryApi.class);
        Call<List<WordDefinition>> call = dictionaryApi.getWordDefinition(word);

        call.enqueue(new Callback<List<WordDefinition>>() {
            @Override
            public void onResponse(Call<List<WordDefinition>> call, Response<List<WordDefinition>> response) {
                if (response.isSuccessful() && response.body() != null && !response.body().isEmpty()) {
                    List<WordDefinition> definitions = response.body();
                    StringBuilder output = new StringBuilder();
                    for (WordDefinition definition : definitions) {
                        output.append(definition.getWord()).append("\n");
                        for (WordDefinition.Meaning meaning : definition.getMeanings()) {
                            output.append(meaning.getPartOfSpeech()).append(":\n");
                            for (WordDefinition.Meaning.Definition def : meaning.getDefinitions()) {
                                output.append("- ").append(def.getDefinition()).append("\n");
                            }
                        }
                    }
                    definitionOutput.setText(output.toString());
                } else {
                    Toast.makeText(DictionaryActivity.this, "No definition found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<WordDefinition>> call, Throwable t) {
                Log.e("DictionaryActivity", "Error: " + t.getMessage());
                Toast.makeText(DictionaryActivity.this, "Error fetching definition", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
