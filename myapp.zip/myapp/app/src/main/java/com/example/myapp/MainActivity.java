package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button btnTextToSpeech, btnSpeechToText, btnDictionary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Ensure this layout is correctly defined

        // Initialize buttons
        btnTextToSpeech = findViewById(R.id.btnTextToSpeech);
        btnSpeechToText = findViewById(R.id.btnSpeechToText);
        btnDictionary = findViewById(R.id.btnDictionary);

        // Set onClickListeners for each button to navigate to the respective activity
        btnTextToSpeech.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, TextToSpeechActivity.class)));
        btnSpeechToText.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, SpeechToTextActivity.class)));
        btnDictionary.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, DictionaryActivity.class)));
    }

    // Inflate the menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu); // Ensure this matches your XML file name
        return true;
    }

    // Handle menu item selections
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.menu_f) {
            // Navigate to FeaturesActivity
            startActivity(new Intent(MainActivity.this, FeaturesActivity.class));
            return true;
        } else if (item.getItemId() == R.id.about_us) {
            // Navigate to AboutUsActivity
            startActivity(new Intent(MainActivity.this, AboutUsActivity.class));
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }
}
